"use strict";

(async function() {
    // 插件主逻辑
    class DvngeAutocomplete {
        constructor() {
            this.name = 'Dvnge章节自动补全';
            this.id = 'ttq.dvnge.autocomplete';
            this.completer = null;
        }

        async init($page) {
            // 等待编辑器加载
            await this.waitForEditor();

            // 注册自动补全
            this.registerAutocomplete();
        }

        waitForEditor() {
            return new Promise((resolve) => {
                let checkCount = 0;
                const checkEditor = () => {
                    if (window.editorManager && window.editorManager.editor) {
                        resolve();
                    } else if (checkCount < 20) {
                        checkCount++;
                        setTimeout(checkEditor, 500);
                    } else {
                        resolve();
                    }
                };
                checkEditor();
            });
        }

        registerAutocomplete() {
            if (!window.editorManager || !window.editorManager.editor) {
                return;
            }

            const editor = window.editorManager.editor;

            // 移除已存在的同名completer
            if (editor.completers) {
                editor.completers = editor.completers.filter(c =>
                    !c.name || c.name !== 'dvngeCompleter'
                );
            } else {
                editor.completers = [];
            }

            // 创建Dvnge自动补全器
            this.completer = {
                name: 'dvngeCompleter',
                getCompletions: (editor, session, pos, prefix, callback) => {
                    // 只对.js文件生效
                    const file = editorManager.activeFile;
                    if (!file || !file.filename.endsWith('.js')) {
                        return callback(null, []);
                    }

                    // 构建补全列表
                    const completions = this.buildCompletions();
                    callback(null, completions);
                }
            };

            // 添加到编辑器
            editor.completers.push(this.completer);

            // 设置自动触发
            editor.setOptions({
                enableBasicAutocompletion: true,
                enableLiveAutocompletion: true
            });
        }

        buildCompletions() {
            const completions = [];

            // 章节数据模板
            completions.push({
                caption: '章节数据模板',
                snippet: 'const ${1:章节名}数据 = [\n    {\n        角色: "${2}",\n        内容: "${3}",\n    }\n];',
                score: 1000,
                meta: '模板'
            });

            // ====================== 基础属性 ======================
            const properties = [{
                    name: '角色',
                    snippet: '角色: "${1}",'
                },
                {
                    name: '内容',
                    snippet: '内容: "${1}",'
                },
                {
                    name: '背景',
                    snippet: '背景: "${1}",'
                },
                {
                    name: '目标',
                    snippet: '目标: ${1},'
                },
                {
                    name: '目标(章节跳转)',
                    snippet: '目标: {\n    章节: "${1}",\n    索引: ${2:0}\n},'
                },
                {
                    name: '标签',
                    snippet: '标签: "${1}",'
                },
                {
                    name: '自动节点',
                    snippet: '自动节点: ${1:2},'
                },
                {
                    name: '音乐',
                    snippet: '音乐: "${1}",'
                },
                {
                    name: '音效',
                    snippet: '音效: "${1}",'
                },
                {
                    name: '自动存档',
                    snippet: '自动存档: ${1:true},'
                },
                {
                    name: '设置变量',
                    snippet: '设置变量: {\n    "${1}": ${2},\n},'
                },
                {
                    name: '读档时设置变量',
                    snippet: '读档时设置变量: {\n    "${1}": ${2},\n},'
                },
                {
                    name: '条件判断',
                    snippet: '条件: {\n    表达式: "${1:vars.变量名 === true}",\n    真目标: ${2},\n    假目标: ${3},\n},'
                },
                {
                    name: '条件判断(章节跳转)',
                    snippet: '条件: {\n    表达式: "${1:vars.变量名 === true}",\n    真目标: { 章节: "${2}", 索引: ${3:0} },\n    假目标: { 章节: "${4}", 索引: ${5:0} },\n},'
                },
                {
                    name: '解锁CG',
                    snippet: '解锁CG: {\n    名称: "${1}",\n    路径: "${2}",\n},'
                },
                {
                    name: '逐字显示',
                    snippet: '逐字显示: {\n    启用: ${1:true},\n    速度: ${2:0.05},\n},'
                },
                {
                    name: '打字音效',
                    snippet: '打字音效: {\n    启用: ${1:true},\n    路径: "${2}",\n    音量: ${3:1},\n    间隔字符数: ${4:1}\n},'
                },
                {
                    name: '打字音效清除',
                    snippet: '打字音效: null,'
                },
                {
                    name: '自定义功能',
                    snippet: '自定义功能: `\n    ${1:// 自定义代码}\n`,'
                },
                {
                    name: '音乐淡出时间',
                    snippet: '音乐淡出时间: ${1:1000},'
                }
            ];

            properties.forEach(prop => {
                completions.push({
                    caption: prop.name,
                    snippet: prop.snippet,
                    score: 100,
                    meta: '属性'
                });
            });

            // ====================== 立绘系统 ======================
            const sprites = [{
                    name: '立绘左',
                    snippet: '立绘: {\n    左立绘: { 路径: "${1}" },\n},'
                },
                {
                    name: '立绘中',
                    snippet: '立绘: {\n    中立绘: { 路径: "${1}" },\n},'
                },
                {
                    name: '立绘右',
                    snippet: '立绘: {\n    右立绘: { 路径: "${1}" },\n},'
                },
                {
                    name: '立绘(视频)',
                    snippet: '立绘: {\n    ${1:中}立绘: {\n        路径: "${2}",\n        媒体: {\n            循环: ${3:true},\n            播放次数: ${4:-1},\n            播放间隔: ${5:0},\n            音量: ${6:1}\n        }\n    },\n},'
                },
                {
                    name: '立绘隐藏',
                    snippet: '立绘: {\n    ${1:中}立绘: { 隐藏: true },\n},'
                },
                {
                    name: '立绘全',
                    snippet: '立绘: {\n    左立绘: { 路径: "${1}" },\n    中立绘: { 路径: "${2}" },\n    右立绘: { 路径: "${3}" },\n},'
                }
            ];

            sprites.forEach(sprite => {
                completions.push({
                    caption: sprite.name,
                    snippet: sprite.snippet,
                    score: 90,
                    meta: '立绘'
                });
            });

            // ====================== 背景系统 ======================
            completions.push({
                caption: '背景(图片)',
                snippet: '背景: "${1}",',
                score: 95,
                meta: '背景'
            });

            completions.push({
                caption: '背景(视频)',
                snippet: '背景: "${1:video.mp4}",\n背景媒体: {\n    循环: ${2:true},\n    播放次数: ${3:-1},\n    播放间隔: ${4:0},\n    音量: ${5:1}\n},',
                score: 95,
                meta: '背景'
            });

            completions.push({
                caption: '背景(清除)',
                snippet: '背景: null,',
                score: 90,
                meta: '背景'
            });


            // ====================== 动画系统 ======================
            completions.push({
                caption: '动画(对话框)',
                snippet: '动画: {\n    对话框: "${1:动画名称}"\n},',
                score: 90,
                meta: '动画'
            });

            completions.push({
                caption: '动画(背景)',
                snippet: '动画: {\n    背景: "${1:动画名称}"\n},',
                score: 90,
                meta: '动画'
            });

            completions.push({
                caption: '动画(角色)',
                snippet: '动画: {\n    角色: "${1:动画名称}"\n},',
                score: 90,
                meta: '动画'
            });

            completions.push({
                caption: '动画(内容)',
                snippet: '动画: {\n    内容: "${1:动画名称}"\n},',
                score: 90,
                meta: '动画'
            });

            completions.push({
                caption: '动画(左立绘)',
                snippet: '动画: {\n    左立绘: "${1:动画名称}"\n},',
                score: 90,
                meta: '动画'
            });

            completions.push({
                caption: '动画(中立绘)',
                snippet: '动画: {\n    中立绘: "${1:动画名称}"\n},',
                score: 90,
                meta: '动画'
            });

            completions.push({
                caption: '动画(右立绘)',
                snippet: '动画: {\n    右立绘: "${1:动画名称}"\n},',
                score: 90,
                meta: '动画'
            });

            completions.push({
                caption: '动画(头像)',
                snippet: '动画: {\n    头像: "${1:动画名称}"\n},',
                score: 90,
                meta: '动画'
            });

            completions.push({
                caption: '动画(头像容器)',
                snippet: '动画: {\n    头像容器: "${1:动画名称}"\n},',
                score: 90,
                meta: '动画'
            });

            // ====================== 标题系统 ======================
            completions.push({
                caption: '标题配置',
                snippet: '标题: {\n    内容: "${1}",\n    位置: "${2:中}", // 可选: 上、下、左、右、左上、左下、右上、右下、中\n},',
                score: 90,
                meta: '标题'
            });

            completions.push({
                caption: '标题(带样式)',
                snippet: '标题: {\n    内容: "${1}",\n    位置: "${2:中}",\n    样式: { color: "${3:#fff}", fontSize: "${4:24px}" }\n},',
                score: 90,
                meta: '标题'
            });

            completions.push({
                caption: '标题隐藏',
                snippet: '标题: { 显示: false },',
                score: 85,
                meta: '标题'
            });

            // ====================== 头像系统 ======================
            completions.push({
                caption: '头像左',
                snippet: '头像: {\n    路径: "${1}",\n    位置: "左"\n},',
                score: 90,
                meta: '头像'
            });

            completions.push({
                caption: '头像右',
                snippet: '头像: {\n    路径: "${1}",\n    位置: "右"\n},',
                score: 90,
                meta: '头像'
            });

            completions.push({
                caption: '头像',
                snippet: '头像: "${1}", // 默认左',
                score: 85,
                meta: '头像'
            });

            completions.push({
                caption: '头像隐藏',
                snippet: '头像: null,',
                score: 85,
                meta: '头像'
            });

            // ====================== 选项系统 ======================
            completions.push({
                caption: '选项',
                snippet: '选项: [\n    {\n        文本: "${1}",\n        目标: ${2},\n    }\n],',
                score: 95,
                meta: '选项'
            });

            completions.push({
                caption: '选项(带条件)',
                snippet: '选项: [\n    {\n        文本: "${1}",\n        条件: "${2:vars.变量名 === true}",\n        目标: ${3},\n        否则目标: ${4},\n    }\n],',
                score: 90,
                meta: '选项'
            });

            completions.push({
                caption: '选项(带变量)',
                snippet: '选项: [\n    {\n        文本: "${1}",\n        目标: ${2},\n        设置变量: {\n            "${3}": ${4}\n        }\n    }\n],',
                score: 90,
                meta: '选项'
            });

            completions.push({
                caption: '选项(解锁CG)',
                snippet: '选项: [\n    {\n        文本: "${1}",\n        目标: ${2},\n        解锁CG: { 名称: "${3}", 路径: "${4}" }\n    }\n],',
                score: 90,
                meta: '选项'
            });

            // ====================== 输入系统 ======================
            completions.push({
                caption: '输入框完整',
                snippet: '输入: {\n    变量名: "${1:inputVar}",\n    占位符: "${2:请输入...}",\n    提示文字: "${3:请输入内容}",\n    最大长度: ${4:20},\n    必填: ${5:true},\n    目标: ${6:0},\n    按钮文字: "${7:确认}",\n},',
                score: 90,
                meta: '输入'
            });

            completions.push({
                caption: '输入框简化',
                snippet: '输入: {\n    变量名: "${1}",\n    目标: ${2:0},\n},',
                score: 85,
                meta: '输入'
            });

            // 输入框带样式
            completions.push({
                caption: '输入框(带样式)',
                snippet: '输入: {\n    变量名: "${1:inputVar}",\n    占位符: "${2:请输入...}",\n    提示文字: "${3:请输入内容}",\n    最大长度: ${4:20},\n    必填: ${5:true},\n    目标: ${6:0},\n    按钮文字: "${7:确认}",\n    样式: {}\n},',
                score: 88,
                meta: '输入'
            });

            // ====================== 跳转系统 ======================
            completions.push({
                caption: 'HTML跳转',
                snippet: '跳转HTML: {\n    路径: "${1:game.html}",\n},',
                score: 80,
                meta: '跳转'
            });

            completions.push({
                caption: 'HTML跳转(带参数)',
                snippet: '跳转HTML: {\n    路径: "${1:game.html}",\n    参数: "章节=序章&索引=0",\n    传递变量: ["${2:变量名}"]\n},',
                score: 80,
                meta: '跳转'
            });

            // ====================== 调查模式 ======================
            completions.push({
                caption: '调查',
                snippet: '调查: {\n    光标: "${1:pointer}",\n    区域: [\n        {\n            x: ${2:0},\n            y: ${3:0},\n            宽度: ${4:100},\n            高度: ${5:100},\n            贴图: "${6:图片路径}",\n            目标: ${7:0}\n        }\n    ],\n    返回: ${8:0}\n},',
                score: 75,
                meta: '调查'
            });

            completions.push({
                caption: '调查(返回章节)',
                snippet: '调查: {\n    光标: "${1:pointer}",\n    区域: [\n        {\n            x: ${2:0},\n            y: ${3:0},\n            宽度: ${4:100},\n            高度: ${5:100},\n            贴图: "${6:图片路径}",\n            目标: ${7:0}\n        }\n    ],\n    返回: { 章节: "${8}", 索引: ${9:0} }\n},',
                score: 75,
                meta: '调查'
            });

            // ====================== 实用工具 ======================
            completions.push({
                caption: '变量占位符',
                snippet: '{${1}}',
                score: 85,
                meta: '变量'
            });

            completions.push({
                caption: 'wait标签',
                snippet: '<wait=${1:1.5}>',
                score: 85,
                meta: '标签'
            });

            completions.push({
                caption: '节点模板',
                snippet: '{\n    角色: "${1}",\n    内容: "${2}"\n},',
                score: 80,
                meta: '节点'
            });

            completions.push({
                caption: '空节点',
                snippet: '{\n    ${1}\n},',
                score: 85,
                meta: '节点'
            });

            return completions;
        }

        async destroy() {
            // 清理自动补全器
            if (window.editorManager && window.editorManager.editor && this.completer) {
                const editor = window.editorManager.editor;
                if (editor.completers) {
                    editor.completers = editor.completers.filter(c => c !== this.completer);
                }
            }
        }
    }

    // 创建插件实例
    const plugin = new DvngeAutocomplete();

    // 注册到Acode
    if (window.acode) {
        acode.setPluginInit("ttq.dvnge.autocomplete", async (baseUrl, $page, {
            cacheFileUrl,
            cacheFile
        }) => {
            plugin.baseUrl = baseUrl;
            await plugin.init($page, cacheFile, cacheFileUrl);
        });

        acode.setPluginUnmount("ttq.dvnge.autocomplete", () => {
            plugin.destroy();
        });
    }
})();